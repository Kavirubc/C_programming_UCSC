#ifndef TYPES_H
#define TYPES_H

typedef struct StackNode
{
    int data;
    struct StackNode *next;
} StackNode;

#endif
